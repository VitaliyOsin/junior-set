const startDate = new DaysTill();
startDate.run(document.getElementById('root'));