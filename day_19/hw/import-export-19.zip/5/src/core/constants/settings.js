export const Settings = {
    currency: '$'
}